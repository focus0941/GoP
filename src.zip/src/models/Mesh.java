package models;

public class Mesh {
    private float[] positions;
    private int[] indices;
    private float[] normals;
    private float[] uvs;

    public Mesh(float[] positions, float[] uvs) {
        this.positions = positions;
        this.uvs = uvs;
    }

    public Mesh(float[] vertices, int[] indices, float[] normals, float[] uvs) {
        this.positions = vertices;
        this.indices = indices;
        this.normals = normals;
        this.uvs = uvs;
    }

    public float[] getPositions() {
        return positions;
    }

    public void setPositions(float[] positions) {
        this.positions = positions;
    }

    public int[] getIndices() {
        return indices;
    }

    public void setIndices(int[] indices) {
        this.indices = indices;
    }

    public float[] getNormals() {
        return normals;
    }

    public void setNormals(float[] normals) {
        this.normals = normals;
    }

    public float[] getUvs() {
        return uvs;
    }

    public void setUvs(float[] uvs) {
        this.uvs = uvs;
    }
}