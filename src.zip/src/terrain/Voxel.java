/*package terrain;

import org.joml.Vector3f;

public class Voxel {
    private byte type;
    private Vector3f position;

    public Voxel(Vector3f position, byte type) {
        this.position = position;
        this.type = type;
    }

    public byte getType() {
        return type;
    }

    public Vector3f getPosition() {
        return position;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Voxel voxel = (Voxel) obj;
        return type == voxel.type;
    }

    @Override
    public int hashCode() {
        return type;
    }
}
*/