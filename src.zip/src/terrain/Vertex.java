/*package terrain;

import org.joml.Vector2f;
import org.joml.Vector3f;
import java.util.Objects;

public class Vertex {
    private Vector3f position;
    private Vector3f normal;
    private Vector2f uv;

    public Vertex(Vector3f position, Vector3f normal, Vector2f uv) {
        this.position = position;
        this.normal = normal;
        this.uv = uv;
    }

    @Override
    public int hashCode() {
        return Objects.hash(position, normal, uv);
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vertex vertex = (Vertex) obj;

        return position.equals(vertex.position);
    }

    public Vector3f getPosition() {
        return position;
    }

    public Vector3f getNormal() {
        return normal;
    }

    public Vector2f getUV() {
        return uv;
    }
}*/