/*package terrain;

import org.joml.Vector3f;
import utilities.Settings;

public class Node {
    private Node[] children;
    private final byte depth;
    private final float size;
    private final Vector3f origin;
    private short type;
    private float value = -1;

    public Node(Vector3f origin, short type, byte depth, float value) {
        this.origin = origin;
        this.type = type;
        this.depth = depth;
        this.size = Settings.chunkSize * (float) Math.pow(0.5, depth);
    }

    public void split() {
        float halfSize = Settings.chunkSize / (float) Math.pow(2, depth + 1);
        byte newDepth = (byte) (depth + 1);

        children = new Node[] {
                new Node(             origin,                                                         type, newDepth, this.value), // 000 -> 0
                new Node(new Vector3f(origin.x + halfSize, origin.y,            origin.z),            type, newDepth, this.value), // 001 -> 1
                new Node(new Vector3f(origin.x,            origin.y + halfSize, origin.z),            type, newDepth, this.value), // 010 -> 2
                new Node(new Vector3f(origin.x + halfSize, origin.y + halfSize, origin.z),            type, newDepth, this.value), // 011 -> 3
                new Node(new Vector3f(origin.x,            origin.y,            origin.z + halfSize), type, newDepth, this.value), // 100 -> 4
                new Node(new Vector3f(origin.x + halfSize, origin.y,            origin.z + halfSize), type, newDepth, this.value), // 101 -> 5
                new Node(new Vector3f(origin.x,            origin.y + halfSize, origin.z + halfSize), type, newDepth, this.value), // 110 -> 6
                new Node(new Vector3f(origin.x + halfSize, origin.y + halfSize, origin.z + halfSize), type, newDepth, this.value)  // 111 -> 7
        };
    }

    public void collapse() {
        if (!equalChildren()) {
            return;
        }

        this.type = children[0].type;
        children = null;
    }

    public boolean equalChildren() {
        short type = children[0].type;
        float value = children[0].value;

        for (Node child : children) {
            if (child == null || child.type != type || child.getValue() != value) {
                return false;
            }
        }

        return true;
    }

    public byte determineChildIndex(Vector3f position) {
        byte child = 0;
        Vector3f origin = getOrigin();

        if (position.x > origin.x) child |= 1;
        if (position.y > origin.y) child |= 2;
        if (position.z > origin.z) child |= 4;

        return child;
    }

    public boolean isLeaf() {
        return children == null;
    }

    public Node[] getChildren() {
        return children;
    }

    public Vector3f getOrigin() {
        return origin;
    }

    public byte getDepth() {
        return depth;
    }

    public short getType() {
        return type;
    }

    public float getValue() {
        return value;
    }

    public float getSize() {
        return size;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public void setType(short type) {
        this.type = type;
    }
}*/