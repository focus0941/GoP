/*package terrain;

import models.Mesh;
import org.joml.Vector3f;
import utilities.Settings;

public class Octree {
    private final Node root;
    private Mesh mesh;

    public Octree(Vector3f origin) {
        this.root = new Node(origin, (short) 0, (byte) 0, -1);
    }

    public void set(Vector3f position, float value) {
        if (!isOutOfBounds(position)) {
            set(root, position, value);
        } else {
            throw new IndexOutOfBoundsException("Position \"" + position + " is out of octree bounds.");
        }
    }

    private void set(Node node, Vector3f position, float value) {
        if (node.getValue() == value) {
            return;
        } else if (node.getDepth() == Settings.maxDepth) {
            node.setValue(value);
            return;
        } else {
            node.split();
        }

        set(node.getChildren()[node.determineChildIndex(position)], position, value);
    }

    public float getValue(Vector3f position) {
        if (!isOutOfBounds(position)) {
            return getValue(root, position);
        } else {
            throw new IndexOutOfBoundsException("Position: " + position + " is out of octree bounds of " + root.getSize() + ".");
        }
    }

    private float getValue(Node node, Vector3f position) {
        if (node.getDepth() == Settings.maxDepth) {
            return node.getValue();
        }

        if (node.isLeaf()) {
            node.split();
        }

        return getValue(node.getChildren()[node.determineChildIndex(position)], position);
    }

    public boolean isOutOfBounds(Vector3f position) {
        Vector3f origin = root.getOrigin();
        float size = root.getSize();

        return position.x < origin.x || position.x > origin.x + size || position.y < origin.y || position.y > origin.y + size || position.z < origin.z || position.z > origin.z + size;
    }

    public Node getRoot() {
        return root;
    }

    public Mesh getMesh() {
        return mesh;
    }

    public void setMesh(Mesh mesh) {
        this.mesh = mesh;
    }
}*/