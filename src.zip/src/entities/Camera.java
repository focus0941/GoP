package entities;

import org.joml.Math;
import org.joml.Vector3f;
import setup.DisplayManager;
import static org.lwjgl.glfw.GLFW.*;
import static setup.DisplayManager.*;
import static utilities.Settings.windowHeight;
import static utilities.Settings.windowWidth;
import static utilities.Settings.speed;

public class Camera {
    Vector3f position;
    Vector3f rotation;
    public static int sensitivity = 25;
    public static float current_speed;

    public Camera(Vector3f position, Vector3f rotation) {
        this.position = position;
        this.rotation = rotation;
    }

    public void move() {
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
            current_speed = speed / 10f;
        } else if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
            current_speed = speed * 10;
        } else {
            current_speed = speed;
        }

        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
            position.z -= Math.cos(Math.toRadians(rotation.y)) * current_speed;
            position.x += Math.sin(Math.toRadians(rotation.y)) * current_speed;
        }

        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            position.z += Math.cos(Math.toRadians(rotation.y)) * current_speed;
            position.x -= Math.sin(Math.toRadians(rotation.y)) * current_speed;
        }

        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            position.x -= Math.cos(Math.toRadians(rotation.y)) * current_speed;
            position.z -= Math.sin(Math.toRadians(rotation.y)) * current_speed;
        }

        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            position.x += Math.cos(Math.toRadians(rotation.y)) * current_speed;
            position.z += Math.sin(Math.toRadians(rotation.y)) * current_speed;
        }

        if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
            position.y += current_speed;
        }

        if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) {
            position.y -= current_speed;
        }

        double[] x = new double[1];
        double[] y = new double[1];
        glfwGetCursorPos(window, x, y);

        rotation.x += (float) (y[0] - windowHeight / 2f) * (sensitivity / 100f);
        rotation.y += (float) (x[0] - windowWidth / 2f) * (sensitivity / 100f);;
        rotation.x = Math.max(-90, Math.min(90, rotation.x));

        glfwSetCursorPos(DisplayManager.window, windowWidth / 2f, windowHeight / 2f);
    }

    public synchronized Vector3f getPosition() {
        return position;
    }

    public void setPosition(Vector3f position) {
        this.position = position;
    }

    public Vector3f getRotation() {
        return rotation;
    }

    public void setRotation(Vector3f rotation) {
        this.rotation = rotation;
    }
}