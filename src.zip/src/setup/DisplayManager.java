package setup;

import org.lwjgl.glfw.GLFWVidMode;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL.createCapabilities;
import static org.lwjgl.opengl.GL11.*;

public class DisplayManager {
    public static long window = 0;

    public static void createDisplay(int width, int height, String title) {
        if (!glfwInit()) {
            throw new IllegalStateException("Failed to initialize GLFW");
        }

        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
        glfwSwapInterval(1);

        window = glfwCreateWindow(width, height, title, 0, 0);

        if (window == 0) {
            throw new IllegalStateException("Failed to create window");
        }

        GLFWVidMode videoMode = glfwGetVideoMode(glfwGetPrimaryMonitor());

        if (videoMode != null) {
            glfwSetWindowPos(window, videoMode.width() / 2 - width / 2, videoMode.height() / 2 - height / 2);
        }

        glfwShowWindow(window);
        glfwMakeContextCurrent(window);
        createCapabilities();
        glEnable(GL_DEPTH_TEST);
    }

    public static void updateDisplay() {
        glfwPollEvents();
        glfwSwapBuffers(window);
    }
}
