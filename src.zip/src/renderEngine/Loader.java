package renderEngine;

import models.RawModel;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.glVertexAttribPointer;
import static org.lwjgl.opengl.GL30.*;

public class Loader {
    List<Integer> VAOs = new ArrayList<>();
    List<Integer> VBOs = new ArrayList<>();
    HashMap<String, Integer> textures = new HashMap<>();

    public int createVAO() {
        int vaoID = glGenVertexArrays();
        VAOs.add(vaoID);
        glBindVertexArray(vaoID);

        return vaoID;
    }

    public RawModel loadToVAO(float[] vertices, int[] indices, float[] uvs) {
        int vaoID = createVAO();
        storeDataInAttributeList(vertices, 0, 3);
        storeDataInAttributeList(uvs, 1, 2);
        bindIndicesBuffer(indices);
        glBindVertexArray(0);

        return new RawModel(vaoID, indices.length);
    }

    public RawModel loadToVAO(float[] vertices, float[] uvs) {
        int vaoID = createVAO();
        storeDataInAttributeList(vertices, 0, 3);
        storeDataInAttributeList(uvs, 1, 2);
        glBindVertexArray(0);

        return new RawModel(vaoID, vertices.length);
    }

    public int loadTexture(String filename) {
        if (textures.containsKey(filename)){
            return textures.get(filename);
        }

        int width;
        int height;
        ByteBuffer buffer;

        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer w = stack.mallocInt(1);
            IntBuffer h = stack.mallocInt(1);
            IntBuffer channels = stack.mallocInt(1);

            buffer = STBImage.stbi_load("res/textures/" + filename, w, h, channels, 4);

            if (buffer == null) {
                throw new RuntimeException("Error whilst loading file \"" + filename + "\": " + STBImage.stbi_failure_reason());
            }

            width = w.get();
            height = h.get();

            int id = glGenTextures();
            textures.put(filename, id);
            glBindTexture(GL_TEXTURE_2D, id);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, buffer);
            glGenerateMipmap(GL_TEXTURE_2D);
            STBImage.stbi_image_free(buffer);

            System.out.println("textures: " + textures.size());

            return id;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    private void storeDataInAttributeList(float[] data, int attributeNumber, int dimensions) {
        int vboID = glGenBuffers();
        VBOs.add(vboID);
        glBindBuffer(GL_ARRAY_BUFFER, vboID);
        FloatBuffer buffer = storeDataInFloatBuffer(data);
        glBufferData(GL_ARRAY_BUFFER, buffer, GL_STATIC_DRAW);
        glVertexAttribPointer(attributeNumber, dimensions, GL_FLOAT, false, 0, 0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
    }

    public void bindIndicesBuffer(int[] indices) {
        int vboID = glGenBuffers();
        VBOs.add(vboID);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vboID);
        IntBuffer buffer = storeDataInIntBuffer(indices);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, buffer, GL_STATIC_DRAW);
    }

    private FloatBuffer storeDataInFloatBuffer(float[] data) {
        FloatBuffer buffer = BufferUtils.createFloatBuffer(data.length);
        buffer.put(data);
        buffer.flip();

        return buffer;
    }

    private IntBuffer storeDataInIntBuffer(int[] data) {
        IntBuffer buffer = BufferUtils.createIntBuffer(data.length);
        buffer.put(data);
        buffer.flip();

        return buffer;
    }

    public void cleanUp() {
        VAOs.forEach(GL30::glDeleteVertexArrays);
        VBOs.forEach(GL15::glDeleteBuffers);
        textures.values().forEach(GL11::glDeleteTextures);
    }
}