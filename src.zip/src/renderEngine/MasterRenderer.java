package renderEngine;

import entities.Camera;
import entities.Entity;
import models.TexturedModel;
import org.joml.Matrix4f;
import shader.StaticShader;
import utilities.Maths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL13.glActiveTexture;
import static org.lwjgl.opengl.GL20.glDisableVertexAttribArray;
import static org.lwjgl.opengl.GL20.glEnableVertexAttribArray;
import static org.lwjgl.opengl.GL30.glBindVertexArray;

public class MasterRenderer {
    Map<TexturedModel, List<Entity>> entities = new HashMap<>();
    StaticShader shader;

    public MasterRenderer(StaticShader shader) {
        this.shader = shader;
        shader.start();
        shader.loadProjectionMatrix(Maths.createProjectionMatrix());
        shader.stop();
    }

    public void prepare() {
        glClearColor(0.2f, 0.2f, 0.5f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    public void render(Camera camera) {
        prepare();
        shader.start();
        shader.loadViewMatrix(camera);

        for(TexturedModel texturedModel : entities.keySet()) {
            glBindVertexArray(texturedModel.getModel().getVaoID());
            glEnableVertexAttribArray(0);
            glEnableVertexAttribArray(1);

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, texturedModel.getTexture().getTextureID());

            List<Entity> batch = entities.get(texturedModel);

            for(Entity entity : batch) {
                Matrix4f transformationMatrix = Maths.createTransformationMatrix(entity.getPosition(), entity.getRotation(), entity.getScale());
                shader.loadTransformationMatrix(transformationMatrix);

                //glDrawArrays(GL_TRIANGLES, 0, texturedModel.getModel().getVertexCount());
                glDrawElements(GL_TRIANGLES, texturedModel.getModel().getVertexCount(), GL_UNSIGNED_INT, 0);
            }

            glDisableVertexAttribArray(0);
            glDisableVertexAttribArray(1);
            glBindVertexArray(0);
        }

        shader.stop();
        entities.clear();
    }

    public void addEntity(Entity entity) {
        TexturedModel texturedModel = entity.getTexturedModel();
        entities.computeIfAbsent(texturedModel, k -> new ArrayList<>()).add(entity);
    }
}