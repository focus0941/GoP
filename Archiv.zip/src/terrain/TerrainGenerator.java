package terrain;

import static utilities.Settings.chunkSize;
import static utilities.Settings.voxelSize;

public class TerrainGenerator {
    public static void generate(Chunk chunk) {
        float[] values = new float[chunkSize * chunkSize * chunkSize];

        for (int x = 0; x < chunkSize; x++) {
            for (int y = 0; y < chunkSize; y++) {
                for (int z = 0; z < chunkSize; z++) {
                    float wx = chunk.getOrigin().x + x * voxelSize;
                    float wy = chunk.getOrigin().y + y * voxelSize;
                    float wz = chunk.getOrigin().z + z * voxelSize;

                    float bound = 100f;

                    values[x + (y * chunkSize) + (z * chunkSize * chunkSize)] = (float) ((1f / (Math.sqrt((wx-bound)*(wx-bound) + (wy-bound)*(wy-bound) + (wz-bound)*(wz-bound)) - bound + 0.000001)));
                }
            }
        }

        chunk.setValues(values);
    }
}