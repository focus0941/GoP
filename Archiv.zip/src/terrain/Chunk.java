package terrain;

import models.Mesh;
import models.ModelTexture;
import models.TexturedModel;
import org.joml.Vector3f;
import org.joml.Vector3i;
import static setup.Main.loader;
import static utilities.Settings.chunkSize;
import static utilities.Settings.voxelSize;

public class Chunk {
    private short[] types = new short[chunkSize * chunkSize * chunkSize];
    private float[] values = new float[chunkSize * chunkSize * chunkSize];
    private final Vector3f origin;
    private final Vector3i chunkCoords;
    private Mesh mesh;
    private TexturedModel chunkModel;

    public Chunk(Vector3i chunkCoords) {
        this.chunkCoords = chunkCoords;
        this.origin = new Vector3f(chunkCoords).mul(chunkSize * voxelSize);
        TerrainGenerator.generate(this);
    }

    public Chunk(short[] types, float[] values, Vector3f origin, Vector3i chunkCoords, Mesh mesh, TexturedModel chunkModel) {
        this.types = types;
        this.values = values;
        this.origin = origin;
        this.chunkCoords = chunkCoords;
        this.mesh = mesh;
        this.chunkModel = chunkModel;
    }

    public void buildChunkModel() {
        this.mesh = MeshBuilder.buildMesh(this);
        this.chunkModel = new TexturedModel(loader.loadToVAO(this.mesh.getPositions(), this.mesh.getIndices(), this.mesh.getUvs()), new ModelTexture(loader.loadTexture("grass.png")));
    }

    public TexturedModel getChunkModel() {
        if (this.mesh == null) {
            buildChunkModel();
        }

        return this.chunkModel;
    }

    public short[] getTypes() {
        return types;
    }

    public void setTypes(short[] chunkData) {
        this.types = chunkData;
    }

    public short getType(int x, int y, int z) {
        return types[x + (y * chunkSize) + (z * chunkSize * chunkSize)];
    }

    public void setType(int x, int y, int z, short type) {
        this.types[x + (y * chunkSize) + (z * chunkSize * chunkSize)] = type;
    }

    public float[] getValues() {
        return values;
    }

    public void setValues(float[] values) {
        this.values = values;
    }

    public float getValue(int x, int y, int z) {
        return values[x + (y * chunkSize) + (z * chunkSize * chunkSize)];
    }

    public void setValue(int x, int y, int z, float value) {
        this.values[x + (y * chunkSize) + (z * chunkSize * chunkSize)] = value;
    }

    public Vector3f getOrigin() {
        return origin;
    }

    public void setMesh(Mesh mesh) {
       this.mesh = mesh;
    }

    public Mesh getMesh() {
        return mesh;
    }

    public Vector3i getChunkCoords() {
        return chunkCoords;
    }

    public void setChunkModel(TexturedModel chunkModel) {
        this.chunkModel = chunkModel;
    }
}