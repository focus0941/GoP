package models;

import org.joml.Vector2f;
import org.joml.Vector3f;

public class CubeModel {
    public static Vector3f[] facePX = {
            new Vector3f(0.5f,0.5f,-0.5f),
            new Vector3f(0.5f,-0.5f,-0.5f),
            new Vector3f(0.5f,-0.5f,0.5f),
            new Vector3f(0.5f,-0.5f,0.5f),
            new Vector3f(0.5f,0.5f,0.5f),
            new Vector3f(0.5f,0.5f,-0.5f)
    };

    public static Vector3f[] faceNX = {
            new Vector3f(-0.5f,-0.5f,0.5f),
            new Vector3f(-0.5f,-0.5f,-0.5f),
            new Vector3f(-0.5f,0.5f,-0.5f),
            new Vector3f(-0.5f,0.5f,-0.5f),
            new Vector3f(-0.5f,0.5f,0.5f),
            new Vector3f(-0.5f,-0.5f,0.5f)
    };

    public static Vector3f[] facePY = {
            new Vector3f(-0.5f,0.5f,0.5f),
            new Vector3f(-0.5f,0.5f,-0.5f),
            new Vector3f(0.5f,0.5f,-0.5f),
            new Vector3f(0.5f,0.5f,-0.5f),
            new Vector3f(0.5f,0.5f,0.5f),
            new Vector3f(-0.5f,0.5f,0.5f)
    };

    public static Vector3f[] faceNY = {
            new Vector3f(0.5f,-0.5f,-0.5f),
            new Vector3f(-0.5f,-0.5f,-0.5f),
            new Vector3f(-0.5f,-0.5f,0.5f),
            new Vector3f(-0.5f,-0.5f,0.5f),
            new Vector3f(0.5f,-0.5f,0.5f),
            new Vector3f(0.5f,-0.5f,-0.5f)
    };

    public static Vector3f[] facePZ = {
            new Vector3f(0.5f,-0.5f,0.5f),
            new Vector3f(-0.5f,-0.5f,0.5f),
            new Vector3f(-0.5f,0.5f,0.5f),
            new Vector3f(-0.5f,0.5f,0.5f),
            new Vector3f(0.5f,0.5f,0.5f),
            new Vector3f(0.5f,-0.5f,0.5f)
    };

    public static Vector3f[] faceNZ = {
            new Vector3f(-0.5f,0.5f,-0.5f),
            new Vector3f(-0.5f,-0.5f,-0.5f),
            new Vector3f(0.5f,-0.5f,-0.5f),
            new Vector3f(0.5f,-0.5f,-0.5f),
            new Vector3f(0.5f,0.5f,-0.5f),
            new Vector3f(-0.5f,0.5f,-0.5f)
    };

    public static Vector2f[] UVS = {
            new Vector2f(0, 0),
            new Vector2f(0, 1),
            new Vector2f(1, 1),
            new Vector2f(1, 1),
            new Vector2f(1, 0),
            new Vector2f(0, 0)
    };

    public static Vector3f[] NORMALS = {
            new Vector3f(1, 0, 0),
            new Vector3f(-1, 0, 0),
            new Vector3f(0, 1, 0),
            new Vector3f(0, -1, 0),
            new Vector3f(0, 0, 1),
            new Vector3f(0, 0, -1)
    };

    public static float[] vertices = {
            -0.5f, 0.5f, -0.5f,
            -0.5f, -0.5f, -0.5f,
            0.5f, -0.5f, -0.5f,
            0.5f, 0.5f, -0.5f,

            -0.5f, 0.5f, 0.5f,
            -0.5f, -0.5f, 0.5f,
            0.5f, -0.5f, 0.5f,
            0.5f, 0.5f, 0.5f,

            0.5f, 0.5f, -0.5f,
            0.5f, -0.5f, -0.5f,
            0.5f, -0.5f, 0.5f,
            0.5f, 0.5f, 0.5f,

            -0.5f, 0.5f, -0.5f,
            -0.5f, -0.5f, -0.5f,
            -0.5f, -0.5f, 0.5f,
            -0.5f, 0.5f, 0.5f,

            -0.5f, 0.5f, 0.5f,
            -0.5f, 0.5f, -0.5f,
            0.5f, 0.5f, -0.5f,
            0.5f, 0.5f, 0.5f,

            -0.5f, -0.5f, 0.5f,
            -0.5f, -0.5f, -0.5f,
            0.5f, -0.5f, -0.5f,
            0.5f, -0.5f, 0.5f
    };

    public static int[] indices = {
            0, 1, 3,
            3, 1, 2,
            4, 5, 7,
            7, 5, 6,
            8, 9, 11,
            11, 9, 10,
            12, 13, 15,
            15, 13, 14,
            16, 17, 19,
            19, 17, 18,
            20, 21, 23,
            23, 21, 22
    };

    public static float[] uvs = {
            0, 0,
            0, 1,
            1, 1,
            1, 0,

            0, 0,
            0, 1,
            1, 1,
            1, 0,

            0, 0,
            0, 1,
            1, 1,
            1, 0,

            0, 0,
            0, 1,
            1, 1,
            1, 0,

            0, 0,
            0, 1,
            1, 1,
            1, 0,

            0, 0,
            0, 1,
            1, 1,
            1, 0
    };
}