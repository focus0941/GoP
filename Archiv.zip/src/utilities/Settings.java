package utilities;

import org.joml.Vector3i;

public class Settings {
    public static int windowWidth = 920;
    public static int windowHeight = 790;
    public static String windowTitle = "GoXel";

    public static int FPS_CAP = 60;
    public static long nSPF = 1000000000/FPS_CAP;
    public static float NEAR_PLANE = 0.01f;
    public static float FAR_PLANE = 1000000;
    public static float FOV = 90;
    public static Vector3i worldSize = new Vector3i(10, 10,10);
    public static int renderDistance = 100;
    public static final int chunkSize = 16;
    public static float voxelSize = 2f;

    public static float speed = 0.01f;
    public static int sensitivity = 25;
}