package utilities;

import entities.Camera;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import static utilities.Settings.*;

public class Maths {
    public static Matrix4f createTransformationMatrix(Vector3f translation, Vector3f rotation, float scale) {
        Matrix4f matrix = new Matrix4f();
        matrix.identity();
        matrix.translate(translation, matrix);
        matrix.rotateX((float) Math.toRadians(rotation.x));
        matrix.rotateY((float) Math.toRadians(rotation.y));
        matrix.rotateZ((float) Math.toRadians(rotation.z));
        matrix.scale(scale, matrix);

        return matrix;
    }

    public static Matrix4f createProjectionMatrix() {
        float aspectRatio = (float) windowWidth / (float) windowHeight;
        float yScale = (float) (1f / Math.tan(Math.toRadians(FOV / 2f)));
        float xScale = yScale / aspectRatio;
        float zp = FAR_PLANE + NEAR_PLANE;
        float zm = FAR_PLANE - NEAR_PLANE;

        Matrix4f matrix = new Matrix4f();

        matrix.m00(xScale);
        matrix.m11(yScale);
        matrix.m22(-zp / zm);
        matrix.m23(-1);
        matrix.m32(-(2 * FAR_PLANE * NEAR_PLANE) / zm);
        matrix.m33(0);

        return matrix;
    }

    public static Matrix4f createViewMatrix(Camera camera) {
        Matrix4f matrix = new Matrix4f();
        matrix.identity();
        matrix.rotateX((float) Math.toRadians(camera.getRotation().x));
        matrix.rotateY((float) Math.toRadians(camera.getRotation().y));
        matrix.rotateZ((float) Math.toRadians(camera.getRotation().z));
        matrix.translate(new Vector3f(-camera.getPosition().x, -camera.getPosition().y, -camera.getPosition().z), matrix);

        return matrix;
    }
}