package entities;

import models.TexturedModel;
import org.joml.Vector3f;

import java.util.ArrayList;

public class Player extends Entity{
    private ArrayList<Item> Items = new ArrayList<>();
    private Item HandheldItem = new Hand();
    public Player(TexturedModel texturedModel, Vector3f position, Vector3f rotation, float scale) {
        super(texturedModel, position, rotation, scale);
    }

    public void move(){

        super.move();
        HandheldItem.use();
    }
}
