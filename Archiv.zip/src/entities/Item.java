package entities;

import models.ModelTexture;
import models.TexturedModel;

public abstract class Item extends Entity{
    ModelTexture GUITEXTURE;
    public Item(TexturedModel texturedModel, ModelTexture gui) {
        super(texturedModel, null, null, 1);
        GUITEXTURE = gui;
    }

    public abstract void use();
}
