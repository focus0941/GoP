package entities;

public class Hand extends Item {
    public Hand() {
        super(null, null);
    }

    @Override
    public void use() {

    }
}
