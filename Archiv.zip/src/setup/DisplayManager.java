package setup;

import org.lwjgl.glfw.GLFWVidMode;
import utilities.Settings;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL.createCapabilities;
import static org.lwjgl.opengl.GL11.*;

public class DisplayManager {
    public static long window = 0;
    public static long lastFT;
    public static double deltaFT;

    public static void createDisplay(int width, int height, String title) {
        lastFT = System.nanoTime();
        if(!glfwInit()) {
            throw new IllegalStateException("Failed to initialize GLFW");
        }

        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
        glfwWindowHint(GLFW_SAMPLES, 4);
        glfwSwapInterval(1);

        window = glfwCreateWindow(width, height, title, 0, 0);

        if(window == 0) {
            throw new IllegalStateException("Failed to create window");
        }

        GLFWVidMode videoMode = glfwGetVideoMode(glfwGetPrimaryMonitor());

        if(videoMode != null) {
            glfwSetWindowPos(window, videoMode.width() / 2 - width / 2, videoMode.height() / 2 - height / 2);
        }

        glfwShowWindow(window);
        glfwMakeContextCurrent(window);
        createCapabilities();
        //glEnable(GL_CULL_FACE);
        //glCullFace(GL_BACK);
        glEnable(GL_DEPTH_TEST);
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

    }

    public static void updateDisplay() {
        deltaFT = System.nanoTime() - lastFT;
        if (deltaFT < Settings.nSPF) {
            try {
                Thread.sleep((long) (Settings.nSPF - deltaFT)/1000000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        glfwPollEvents();
        glfwSwapBuffers(window);
        deltaFT = ((double) System.nanoTime() - (double) lastFT) / 1_000_000_000;
        lastFT = System.nanoTime();

    }
}
