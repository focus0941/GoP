package setup;

import entities.Camera;
import entities.Entity;
import entities.Light;
import models.ModelTexture;
import models.TexturedModel;
import org.joml.Vector3f;
import org.joml.Vector3i;
import renderEngine.Loader;
import renderEngine.MasterRenderer;
import renderEngine.OBJLoader;
import shader.StaticShader;
import terrain.*;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static setup.DisplayManager.updateDisplay;
import static setup.DisplayManager.window;
import static utilities.Settings.*;

public class Main {
    public static final java.lang.Runtime runtime = java.lang.Runtime.getRuntime();
    public static Loader loader = new Loader();
    public static List<Entity> entities = new ArrayList<>();
    public static List<Light> lights = new ArrayList<>();
    public static HashMap<Vector3i, Chunk> allChunks = new HashMap<>();

    public static void main(String[] args) {
        DisplayManager.createDisplay(windowWidth, windowHeight, windowTitle);
        StaticShader shader = new StaticShader();
        MasterRenderer renderer = new MasterRenderer(shader);
        Camera camera = new Camera(new Vector3f(), new Vector3f());

        List<Chunk> loadedChunks = new ArrayList<>();

        for (int x = 0; x < worldSize.x; x++) {
            for (int y = 0; y < worldSize.y; y++) {
                for (int z = 0; z < worldSize.z; z++) {
                    Vector3i chunkPos = new Vector3i(x,y,z);

                    if (!allChunks.containsKey(chunkPos)) {
                        allChunks.put(chunkPos, new Chunk(chunkPos));
                    }

                    loadedChunks.add(allChunks.get(chunkPos));
                }
            }
        }

        int totalTriCount = 0;

        for (Chunk chunk : loadedChunks) {
            chunk.buildChunkModel();
            totalTriCount += chunk.getMesh().getIndices().length / 3;
        }

        entities.add(new Entity(
                new TexturedModel(
                        OBJLoader.loadObjModel("egg", loader), new ModelTexture(loader.loadTexture("Stone1.png"))), new Vector3f(3), new Vector3f(), 3));

        boolean wireframe = false;

        System.out.println("Triangle count: " + totalTriCount);
        System.out.println("Voxel count: " + worldSize.x * worldSize.y * worldSize.z * chunkSize * chunkSize * chunkSize);
        System.out.println("Memory used: " + runtime.totalMemory()/1_000_000f + " Mb");

        while (!glfwWindowShouldClose(DisplayManager.window) && glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS) {
            camera.move();
            renderer.prepare();

            for (Entity entity : entities) {
                renderer.addEntity(entity);
            }
            for (Chunk chunk : loadedChunks) {
                renderer.addChunk(chunk);
            }

            if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS && !wireframe) {
                wireframe = true;
            } else if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS && wireframe) {
                wireframe = false;
            }

            if (wireframe) {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            } else {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            }

            renderer.render(lights, camera);
            updateDisplay();
        }

        loader.cleanUp();
        shader.cleanUp();
        glfwDestroyWindow(window);
        glfwTerminate();
    }
}